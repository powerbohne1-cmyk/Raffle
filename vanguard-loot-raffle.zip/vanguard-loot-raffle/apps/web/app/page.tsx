export default function Home(){return <main style={{padding:32}}><h1>Vanguard Academy</h1><p><a href="/mi-loot-history" style={{color:'#8ab4ff'}}>MI Loot History</a></p></main>}
