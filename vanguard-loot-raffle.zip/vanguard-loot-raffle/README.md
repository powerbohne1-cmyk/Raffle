# Vanguard Loot Raffle

Discord-first Loot-Raffle mit Supabase und einer schlanken Website-History.

## Funktionen
- `/raffle` öffnet ein einfaches Admin-Menü mit Buttons.
- Raffle-Titel, Starttext, Abschlusstext und Timer frei wählbar.
- Gespeicherter Loot-Katalog, Auswahl per Haken/Select, Mengen mit +/-.
- Lootklassen frei benennbar; visuelle Farben: Gold, Purple, Blue, Red.
- Cooldown pro Lootklasse.
- Teilnehmer wählen nur Loot, den sie gewinnen wollen.
- Ein gemeinsamer Spin verteilt alle Loots.
- @everyone beim Start und automatisch 1 Minute vor Ende.
- `/cooldown` und `/loothistory`.
- Website speichert nur Ergebnis-Karten mit Titel `MI DD.MM.YYYY HH:mm`.
- Screenshot-Import-Hook via `/loot-screenshot` (nutzt optional OpenAI Vision, wenn OPENAI_API_KEY gesetzt ist).

## Start
1. `cp .env.example .env` und Werte eintragen.
2. `supabase/schema.sql` in Supabase SQL Editor ausführen.
3. `npm install`
4. Bot: `npm run dev:bot`
5. Website: `npm run dev:web`

## Discord Rechte
Der Bot benötigt u.a. Send Messages, Embed Links, Use Application Commands und Mention Everyone.
